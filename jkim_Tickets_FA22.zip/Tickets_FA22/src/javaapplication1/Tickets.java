package javaapplication1;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

@SuppressWarnings("serial")
public class Tickets extends JFrame implements ActionListener {

	// class level member objects
	Dao dao = new Dao(); // for CRUD operations
	Boolean chkIfAdmin = null;

	// Main menu object items
	private JMenu mnuFile = new JMenu("File");
	private JMenu mnuAdmin = new JMenu("Admin");
	private JMenu mnuTickets = new JMenu("Tickets");

	// Sub menu item objects for all Main menu item objects
	JMenuItem mnuItemExit;
	JMenuItem mnuItemRefresh;
	JMenuItem mnuItemUpdate;
	JMenuItem mnuItemDelete;
	JMenuItem mnuItemOpenTicket;
	JMenuItem mnuItemViewTicket;
	JMenuItem mnuItemSelectTicket;
	private JTable jt;

	public Tickets(Boolean isAdmin) {
		if (isAdmin != chkIfAdmin) {
			System.out.println("Admin Approved");
		}
		chkIfAdmin = isAdmin;
		createMenu();
		prepareGUI();
	}

	private void createMenu() {

		/* Initialize sub menu items **************************************/

		// initialize sub menu item for File main menu
		mnuItemExit = new JMenuItem("Exit");
		// add to File main menu item
		mnuFile.add(mnuItemExit);
		
		// initialize first sub menu item for Tickets main menu
		mnuItemOpenTicket = new JMenuItem("Open Ticket");
		// add to Ticket Main menu item
		mnuTickets.add(mnuItemOpenTicket);

		// initialize second sub menu item for Tickets main menu
		mnuItemViewTicket = new JMenuItem("View All Ticket");
		// add to Ticket Main menu item
		mnuTickets.add(mnuItemViewTicket);
		
		// initialize any more desired sub menu items below
		
		// initialize sub menu item for File main menu
		mnuItemRefresh = new JMenuItem("Refresh");
		// add to File main menu item
		mnuFile.add(mnuItemRefresh);
		
		//only show this tab if the program is accessed through admin credential 
		if (chkIfAdmin == true) {
			// initialize first sub menu items for Admin main menu
			mnuItemUpdate = new JMenuItem("Update Ticket");
			// add to Admin main menu item
			mnuAdmin.add(mnuItemUpdate);
			
			// initialize second sub menu items for Admin main menu
			mnuItemDelete = new JMenuItem("Delete Ticket");
			// add to Admin main menu item
			mnuAdmin.add(mnuItemDelete);
		}
		
		// initialize second sub menu item for Tickets main menu
		mnuItemSelectTicket = new JMenuItem("Select Ticket");
		// add to Ticket Main menu item
		mnuTickets.add(mnuItemSelectTicket);	

		/* Add action listeners for each desired menu item *************/
		mnuItemExit.addActionListener(this);
		mnuItemOpenTicket.addActionListener(this);
		mnuItemViewTicket.addActionListener(this);

		 /*
		  * continue implementing any other desired sub menu items (like 
		  * for update and delete sub menus for example) with similar 
		  * syntax & logic as shown above
		 */
		
		mnuItemRefresh.addActionListener(this);
		if (chkIfAdmin == true) {
			mnuItemUpdate.addActionListener(this);
			mnuItemDelete.addActionListener(this);
		}
		mnuItemSelectTicket.addActionListener(this);
		

	}

	private void prepareGUI() {

		// create JMenu bar
		JMenuBar bar = new JMenuBar();
		bar.add(mnuFile); // add main menu items in order, to JMenuBar
		if (chkIfAdmin == true) { //only show this to admin
			bar.add(mnuAdmin);
		}
		bar.add(mnuTickets);
		// add menu bar components to frame
		setJMenuBar(bar);

		addWindowListener(new WindowAdapter() {
			// define a window close operation
			public void windowClosing(WindowEvent wE) {
				System.exit(0);
			}
		});
		// set frame options
		setSize(400, 400);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setLocationRelativeTo(null);
		

		try {
			jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
			jt.setBounds(30, 40, 200, 400);
			JScrollPane sp = new JScrollPane(jt);
			add(sp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// implement actions for sub menu items
		//if Exit btn is pressed then the system will exit
		if (e.getSource() == mnuItemExit) {
			System.exit(0);
		}
		//if Open Ticket btn is pressed the system will add new ticket to the system
		else if (e.getSource() == mnuItemOpenTicket) {
			openTicket();
		}
		//If View Ticket is pressed the system will display existing tickets
		else if (e.getSource() == mnuItemViewTicket) {
			viewAll();
		}
		else if (e.getSource() == mnuItemRefresh) {
			viewAll();
		}
		else if (e.getSource() == mnuItemSelectTicket) {
			selectTicket();
		}
		else if (e.getSource() == mnuItemUpdate) {
			updateTicket();
		}
		else if (e.getSource() == mnuItemDelete) {
			deleteTicket();
		}	
	}

	private void openTicket() {
		// get ticket information
		String ticketName = JOptionPane.showInputDialog(null, "Enter your name");
		String ticketDesc = JOptionPane.showInputDialog(null, "Enter a ticket description");

		// insert ticket information to database

		
		
		if(ticketName == null || (ticketName != null && ("".equals(ticketName))) || ticketDesc == null || (ticketDesc != null && ("".equals(ticketDesc))))   
		{
			JOptionPane.showMessageDialog(null, "Ticket creation failed: empty name / description.");
			System.out.println("Ticket creation failed: empty name / description.");
		} else {
			
			int id = dao.insertRecords(ticketName, ticketDesc);
			
			// display results if successful or not to console / dialog box
			if (id != 0) {
				System.out.println("Ticket ID : " + id + " created successfully!!!");
				JOptionPane.showMessageDialog(null, "Ticket id: " + id + " created");
			} else {
				System.out.println("Ticket cannot be created!!!");
			}
		}
	}

	private void deleteTicket() {
		String deleteTicketId = JOptionPane.showInputDialog(null, "Enter the ticket id to delete");
		
		if(deleteTicketId == null || (deleteTicketId != null && ("".equals(deleteTicketId)))) {
			JOptionPane.showMessageDialog(null, "Ticket view failed: empty id.");
		}
		else {
			int tid = Integer.parseInt(deleteTicketId);
			
			int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete ticket " + tid + "?", "Warning!", JOptionPane.YES_NO_OPTION);
			if (reply == JOptionPane.YES_OPTION) {
				 dao.deleteRecords(tid);
			} 
			else {
				JOptionPane.showMessageDialog(null, "Ticket " + tid + " was not deleted.");
			}
		}
	}

	private void updateTicket() {
		
		String updateTicketID = JOptionPane.showInputDialog(null, "Please enter id of the ticket to update");
		String ticketDesc = JOptionPane.showInputDialog(null, "Append to the ticket description");
		String updateTicketStatus = JOptionPane.showInputDialog(null, "Update the ticket status");
		
		if(updateTicketID == null || ticketDesc == null || updateTicketStatus == null || (updateTicketID != null && ("".equals(updateTicketID))) || (ticketDesc != null && ("".equals(ticketDesc))) || (updateTicketStatus != null && ("".equals(updateTicketStatus)))) {
			JOptionPane.showMessageDialog(null, "Ticket view failed: empty id.");
		}
		else {
			int tid = Integer.parseInt(updateTicketID);
			
			dao.updateRecords(tid, ticketDesc, updateTicketStatus);
		}
	}

	private void viewAll() {
		// retrieve all tickets details for viewing in JTable
		try {

			// Use JTable built in functionality to build a table model and
			// display the table model off your result set!!!
			jt.setModel(ticketsJTable.buildTableModel(dao.readRecords()));
			jt.revalidate();
			jt.repaint();

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	//If Select Ticket has been pressed, the system will show a dialog asking user to input specific ticket id and display the information
	private void selectTicket() {
		String ticketId = JOptionPane.showInputDialog(null, "Enter the ticket ID");
		
		if(ticketId == null || (ticketId != null && ("".equals(ticketId)))) {
			JOptionPane.showMessageDialog(null, "Ticket view failed: empty id.");
		}
		else {
			int tid = Integer.parseInt(ticketId);
			try {
				jt.setModel(ticketsJTable.buildTableModel(dao.selectRecord(tid)));
				jt.revalidate();
				jt.repaint();
			}
			catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
	}

}
